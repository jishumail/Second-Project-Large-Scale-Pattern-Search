README
======
Below are the steps to load dataset 0 to HDFS.

hadoop fs -mkdir dataset0
hadoop fs -put dummy.txt dataset0/dummy.txt
hadoop fs -put shakespeare.txt dataset0/shakespeare.txt
