README
======
Below are the steps to load dataset 1 to HDFS.

hadoop fs -mkdir dataset1
hadoop fs -put hamlet.txt dataset1/hamlet.txt
hadoop fs -put macbeth.txt dataset1/macbeth.txt
hadoop fs -put othello.txt dataset1/othello.txt
