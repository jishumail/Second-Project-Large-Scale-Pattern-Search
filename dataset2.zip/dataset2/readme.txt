README
======
Below are the steps to load dataset 2 to HDFS.

hadoop fs -mkdir dataset2
hadoop fs -put transaction1.txt dataset1/transaction1.txt
hadoop fs -put transaction2.txt dataset1/transaction2.txt
